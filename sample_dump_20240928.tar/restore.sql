--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.22
-- Dumped by pg_dump version 10.22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX public."IDX_session_expire";
ALTER TABLE ONLY public.users DROP CONSTRAINT users_username_key;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey1;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.session_table DROP CONSTRAINT session_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sample ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.session_table;
DROP SEQUENCE public.sample_id_seq;
DROP TABLE public.sample;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: jkelkar
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO jkelkar;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: jkelkar
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: sample; Type: TABLE; Schema: public; Owner: jkelkar
--

CREATE TABLE public.sample (
    title character varying(150),
    body text,
    data text,
    userid integer,
    ts timestamp without time zone,
    id integer NOT NULL
);


ALTER TABLE public.sample OWNER TO jkelkar;

--
-- Name: sample_id_seq; Type: SEQUENCE; Schema: public; Owner: jkelkar
--

CREATE SEQUENCE public.sample_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sample_id_seq OWNER TO jkelkar;

--
-- Name: sample_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jkelkar
--

ALTER SEQUENCE public.sample_id_seq OWNED BY public.sample.id;


--
-- Name: session_table; Type: TABLE; Schema: public; Owner: jkelkar
--

CREATE TABLE public.session_table (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session_table OWNER TO jkelkar;

--
-- Name: users; Type: TABLE; Schema: public; Owner: jkelkar
--

CREATE TABLE public.users (
    id integer NOT NULL,
    fname character varying(60),
    lname character varying(60),
    username character varying(10),
    email character varying(128),
    password character varying(90),
    regkey character varying(90),
    chgkey character varying(90)
);


ALTER TABLE public.users OWNER TO jkelkar;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: jkelkar
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO jkelkar;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jkelkar
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: sample id; Type: DEFAULT; Schema: public; Owner: jkelkar
--

ALTER TABLE ONLY public.sample ALTER COLUMN id SET DEFAULT nextval('public.sample_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: jkelkar
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: sample; Type: TABLE DATA; Schema: public; Owner: jkelkar
--

COPY public.sample (title, body, data, userid, ts, id) FROM stdin;
\.
COPY public.sample (title, body, data, userid, ts, id) FROM '$$PATH$$/2968.dat';

--
-- Data for Name: session_table; Type: TABLE DATA; Schema: public; Owner: jkelkar
--

COPY public.session_table (sid, sess, expire) FROM stdin;
\.
COPY public.session_table (sid, sess, expire) FROM '$$PATH$$/2967.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: jkelkar
--

COPY public.users (id, fname, lname, username, email, password, regkey, chgkey) FROM stdin;
\.
COPY public.users (id, fname, lname, username, email, password, regkey, chgkey) FROM '$$PATH$$/2970.dat';

--
-- Name: sample_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jkelkar
--

SELECT pg_catalog.setval('public.sample_id_seq', 5, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jkelkar
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: session_table session_pkey; Type: CONSTRAINT; Schema: public; Owner: jkelkar
--

ALTER TABLE ONLY public.session_table
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: jkelkar
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey1; Type: CONSTRAINT; Schema: public; Owner: jkelkar
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey1 PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: jkelkar
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: jkelkar
--

CREATE INDEX "IDX_session_expire" ON public.session_table USING btree (expire);


--
-- PostgreSQL database dump complete
--

